(function() {
  let container = null;
  const ICONS = { success: '✓', error: '✕', info: 'i' };
 
  window.showToast = function(message, type = 'info', duration = 3500) {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.innerHTML = '<span>' + (ICONS[type] || '') + '</span><span>' + message + '</span>';
    container.appendChild(toast);
    const remove = () => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    };
    setTimeout(remove, duration);
    toast.addEventListener('click', remove);
  };
})();
 

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
 
function debounce(fn, delay) {
  let t;
  return function(...args) { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
}
 

(async function initInventarioPage() {
  if (!document.getElementById('product-table')) return;
 
  const session = await requireAuth();
  if (!session) return;
 

  const userEl = document.getElementById('user-email');
  if (userEl) userEl.textContent = session.user.email;
 

  window.handleLogout = async function() {
    await signOut();
    window.location.href = 'login.html';
  };
 

  let editingId = null;
 

  async function loadProducts(search = '') {
    const tbody = document.getElementById('product-table');
    tbody.innerHTML = '<tr class="state-row"><td colspan="6">Cargando…</td></tr>';
    try {
      const products = await getProducts({ search });
      updateStats(products);
 
      if (!products.length) {
        tbody.innerHTML = '<tr class="state-row"><td colspan="6">Sin productos registrados.</td></tr>';
        return;
      }
 
  
      tbody.innerHTML = products.map(p => {
        const stock = getStockStatus(p.cantidad);    
        return `<tr>
          <td>${p.imagen_url
            ? `<img src="${escapeHtml(p.imagen_url)}" class="thumb" onerror="this.style.display='none'">`
            : '—'}</td>                                 
          <td>${escapeHtml(p.nombre)}</td>             
          <td class="desc">${escapeHtml(p.descripcion || '—')}</td>  
          <td class="precio">${formatPrice(p.precio)}</td>   
          <td><span class="stock-badge ${stock.class}">${stock.label}</span></td>
          <td class="acciones">
            <button class="btn-edit"   onclick="startEdit('${p.id}')">✏️</button>
            <button class="btn-delete" onclick="confirmDelete('${p.id}')">🗑️</button>
          </td>
        </tr>`;
      }).join('');
    } catch(e) {
      tbody.innerHTML = `<tr class="state-row"><td colspan="6" style="color:var(--danger)">Error: ${e.message}</td></tr>`;
    }
  }
 
  function updateStats(products) {
    const stats = calculateStats(products);
    const el1 = document.getElementById('stat-total');
    const el2 = document.getElementById('stat-value');
    if (el1) el1.textContent = stats.total;
    if (el2) el2.textContent = formatPrice(stats.totalVal);
  }
 
  /* ---- modal ---- */
  window.openModal = function(id = null) {
    editingId = id;
    const modal = document.getElementById('modal-overlay');
    const title = document.getElementById('modal-title');
    if (id) {
      title.innerHTML = 'Editar <span>Producto</span>';
    } else {
      title.innerHTML = 'Nuevo <span>Producto</span>';
      clearForm();
    }
    modal.showModal ? modal.showModal() : modal.removeAttribute('hidden');
  };
 
  window.closeModal = function() {
    const modal = document.getElementById('modal-overlay');
    modal.close ? modal.close() : modal.setAttribute('hidden', '');
    editingId = null;
    clearForm();
  };
 
  function clearForm() {
    ['f-name', 'f-desc', 'f-price', 'f-qty', 'f-img', 'edit-id'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
  }
 

  window.startEdit = async function(id) {
    try {
      const p = await getProductById(id);
      document.getElementById('edit-id').value  = p.id;
      document.getElementById('f-name').value   = p.nombre      || '';  
      document.getElementById('f-desc').value   = p.descripcion || '';  
      document.getElementById('f-price').value  = p.precio      || '';  
      document.getElementById('f-qty').value    = p.cantidad    || '';   
      document.getElementById('f-img').value    = p.imagen_url  || '';   
      openModal(id);
    } catch(e) {
      showToast(e.message, 'error');
    }
  };
 

  window.saveProduct = async function() {

    const data = {
      nombre:      document.getElementById('f-name').value,  
      descripcion: document.getElementById('f-desc').value,   
      precio:      document.getElementById('f-price').value,   
      cantidad:    document.getElementById('f-qty').value,    
      imagen_url:  document.getElementById('f-img').value,    
    };
 
    const errors = validateProductForm(data);
    if (errors.length) return showToast(errors[0], 'error');
 
    const btn = document.getElementById('btn-save');
    btn.disabled = true;
    btn.textContent = 'Guardando…';
 
    try {
      if (editingId) {
        await updateProduct(editingId, data);
        showToast('Producto actualizado ✓', 'success');
      } else {
        await createProduct(data);
        showToast('Producto creado ✓', 'success');
      }
      closeModal();
      await loadProducts(document.getElementById('search-input')?.value || '');
    } catch(e) {
      showToast(e.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Guardar';
    }
  };
 

  window.confirmDelete = async function(id) {
    if (!confirm('¿Eliminar este producto?')) return;
    try {
      await deleteProduct(id);
      showToast('Producto eliminado.', 'success');
      await loadProducts(document.getElementById('search-input')?.value || '');
    } catch(e) {
      showToast(e.message, 'error');
    }
  };
 

  window.filterProducts = debounce(function() {
    const search = document.getElementById('search-input')?.value || '';
    loadProducts(search);
  }, 300);
 

  await loadProducts();
})();