// ============================================================
//  auth.js — usa window.sb definido en supabase.js
//  NO necesita import/export
// ============================================================

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validatePassword(password) {
  return password.length >= 6 ? null : 'La contraseña debe tener al menos 6 caracteres.';
}

async function signUp(email, password) {
  const { data, error } = await sb.auth.signUp({ email, password });
  if (error) throw error;
  return (data.user && !data.session) ? { needsConfirmation: true } : { session: data.session };
}

async function signIn(email, password) {
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.session;
}

async function signOut() {
  const { error } = await sb.auth.signOut();
  if (error) throw error;
}

async function getCurrentUser() {
  const { data: { user } } = await sb.auth.getUser();
  return user;
}

async function requireAuth() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { window.location.href = 'login.html'; return null; }
  return session;
}

async function redirectIfLoggedIn() {
  const { data: { session } } = await sb.auth.getSession();
  if (session) window.location.href = 'inventario.html';
}

function rememberEmail(email) { localStorage.setItem('inv_email', email); }
function getRememberedEmail()  { return localStorage.getItem('inv_email') || ''; }

// ---- lógica de login.html ----
(async function initLoginPage() {
  if (!document.getElementById('panel-login')) return;
  await redirectIfLoggedIn();

  const emailInput = document.getElementById('login-email');
  if (emailInput) emailInput.value = getRememberedEmail();

  window.switchTab = function(tab) {
    document.querySelectorAll('.tab-btn').forEach(b =>
      b.classList.toggle('active', b.dataset.tab === tab)
    );
    document.querySelectorAll('.form-panel').forEach(p =>
      p.classList.toggle('active', p.id === 'panel-' + tab)
    );
  };

  window.handleLogin = async function() {
    const email    = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const msg      = document.getElementById('login-msg');
    const btn      = document.getElementById('btn-login');

    if (!validateEmail(email))     return setMsg(msg, 'Correo inválido.', 'error');
    const pwErr = validatePassword(password);
    if (pwErr)                     return setMsg(msg, pwErr, 'error');

    btn.disabled = true; btn.textContent = 'Ingresando…';
    try {
      await signIn(email, password);
      rememberEmail(email);
      window.location.href = 'inventario.html';
    } catch(e) {
      setMsg(msg, e.message, 'error');
    } finally {
      btn.disabled = false; btn.textContent = 'Iniciar sesión';
    }
  };

  window.handleRegister = async function() {
    const email    = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirm  = document.getElementById('reg-confirm').value;
    const msg      = document.getElementById('reg-msg');
    const btn      = document.getElementById('btn-register');

    if (!validateEmail(email))    return setMsg(msg, 'Correo inválido.', 'error');
    const pwErr = validatePassword(password);
    if (pwErr)                    return setMsg(msg, pwErr, 'error');
    if (password !== confirm)     return setMsg(msg, 'Las contraseñas no coinciden.', 'error');

    btn.disabled = true; btn.textContent = 'Creando cuenta…';
    try {
      const result = await signUp(email, password);
      if (result.needsConfirmation) {
        setMsg(msg, 'Revisa tu correo para confirmar la cuenta.', 'ok');
      } else {
        window.location.href = 'inventario.html';
      }
    } catch(e) {
      setMsg(msg, e.message, 'error');
    } finally {
      btn.disabled = false; btn.textContent = 'Crear cuenta';
    }
  };
})();

function setMsg(el, text, type) {
  if (!el) return;
  el.textContent = text;
  el.className = 'msg ' + type;
}