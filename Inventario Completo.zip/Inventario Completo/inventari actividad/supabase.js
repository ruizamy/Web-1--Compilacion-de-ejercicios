const SUPABASE_URL = "https://sjirztkyitzcnozeqkpk.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNqaXJ6dGt5aXR6Y25vemVxa3BrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgyNzk3NjQsImV4cCI6MjA5Mzg1NTc2NH0.jiSJdCpkLMhsfqUdugiTnNR-ygpXVy_eEhMYirKPGto"; //clave anon

const { createClient } = window.supabase;

window.sb = createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY
);