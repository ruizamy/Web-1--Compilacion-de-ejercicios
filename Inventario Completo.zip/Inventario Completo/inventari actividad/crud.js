// ============================================================
//  crud.js — usa window.sb definido en supabase.js
//  ⚠️  Nombre de tabla: 'productos' (ajusta si usaste otro nombre)
// ============================================================

const productos = 'productos'; // <- cambia a 'products' si así la creaste en Supabase

async function createProduct(productData) {
  const { data: { user } } = await sb.auth.getUser();
  if (!user) throw new Error('No autenticado');

  const payload = {
    nombre:        productData.nombre.trim(),
    descripcion: productData.descripcion?.trim() || null,
    precio:       parseFloat(productData.precio),
    cantidad:    parseInt(productData.cantidad, 10),
    imagen_url:   productData.imagen_url?.trim() || null,
    user_id:     user.id,
  };

  const { data, error } = await sb.from(productos).insert([payload]).select().single();
  if (error) throw error;
  return data;
}

async function getProducts({ search = '', orderBy = 'created_at', ascending = false } = {}) {
  let query = sb.from(productos).select('*').order(orderBy, { ascending });
  if (search.trim()) {
    query = query.or(`nombre.ilike.%${search}%,descripcion.ilike.%${search}%`);
  }
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

async function getProductById(id) {
  const { data, error } = await sb.from(productos).select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

async function updateProduct(id, updates) {
  const payload = {
    nombre:        updates.nombre.trim(),
    descripcion: updates.descripcion?.trim() || null,
    precio:       parseFloat(updates.precio),
    cantidad:    parseInt(updates.cantidad, 10),
    imagen_url:   updates.imagen_url?.trim() || null,
  };
  const { data, error } = await sb.from(productos).update(payload).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

async function deleteProduct(id) {
  const { error } = await sb.from(productos).delete().eq('id', id);
  if (error) throw error;
  return true;
}

// ---- helpers ----
function calculateStats(products) {
  return {
    total:    products.length,
    totalQty: products.reduce((s, p) => s + (p.cantidad || 0), 0),
    totalVal: products.reduce((s, p) => s + (p.precio || 0) * (p.cantidad || 0), 0),
    lowStock: products.filter(p => p.cantidad > 0 && p.cantidad <= 5).length,
    noStock:  products.filter(p => p.cantidad === 0).length,
  };
}

function getStockStatus(cantidad) {
  if (cantidad === 0) return { class: 'no-stock',  label: 'Sin stock' };
  if (cantidad <= 5)  return { class: 'low-stock', label: cantidad + ' — Bajo' };
  return              { class: 'in-stock',  label: String(cantidad) };
}

function formatPrice(precio) {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency', currency: 'COP',
    minimumFractionDigits: 0, maximumFractionDigits: 0,
  }).format(precio);
}

function validateProductForm(data) {
  const errors = [];
  if (!data.nombre?.trim()) errors.push('El nombre es obligatorio.');
  if (!data.precio || isNaN(parseFloat(data.precio)) || parseFloat(data.precio) < 0)
    errors.push('El precio debe ser un número válido ≥ 0.');
  if (!data.cantidad || isNaN(parseInt(data.cantidad)) || parseInt(data.cantidad) < 0)
    errors.push('La cantidad debe ser un entero ≥ 0.');
  if (data.imagen_url?.trim()) {
    try { new URL(data.imagen_url.trim()); } catch { errors.push('La URL de imagen no es válida.'); }
  }
  return errors;
}