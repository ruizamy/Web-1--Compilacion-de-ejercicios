const SUPABASE_URL = 'https://wvyvuwdohgfxigvvcitd.supabase.co';
const SUPABASE_KEY = 'sb_publishable_hyNwQXNfQ82vZSILQYzKyA_1oq03ZdH';

const clienteSupabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

let todosLosProductos = [];

// 🔧 Normalizar texto (evita problemas con tildes y mayúsculas)
function normalizarTexto(texto) {
  return texto
    ?.toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") || "";
}

// 🚀 Obtener productos desde Supabase
async function obtenerProductos() {
  const { data, error } = await clienteSupabase
    .from('productos')
    .select(`
      id,
      nombre,
      precio,
      imagen,
      categoria_id,
      categoria ( nombre )
    `);

  if (error) {
    console.error('❌ Error al obtener productos:', error);
    return;
  }

  console.log("✅ DATOS RECIBIDOS:", data);

  todosLosProductos = data;
  mostrarProductos(todosLosProductos);
  configurarFiltros();
}

// 🧱 Renderizar productos
function mostrarProductos(productos) {
  const contenedor = document.getElementById('contenedor');
  contenedor.innerHTML = '';

  if (!productos || productos.length === 0) {
    contenedor.innerHTML = '<p>No hay productos en esta categoría.</p>';
    return;
  }

  productos.forEach(producto => {
    const article = document.createElement('article');
    article.classList.add('producto');

    article.innerHTML = `
      <img src="${producto.imagen || ''}" alt="${producto.nombre}" />
      <h3>${producto.nombre}</h3>
      <p>$${producto.precio}</p>
    `;

    contenedor.appendChild(article);
  });
}

// 🎯 Configurar botones de filtro
function configurarFiltros() {
  const botones = document.querySelectorAll('.btn-filtro');

  botones.forEach(boton => {
    boton.addEventListener('click', (e) => {
      // UI activa
      botones.forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');

      const categoriaSeleccionada = e.target.dataset.categoria;

      console.log("📌 Categoría seleccionada:", categoriaSeleccionada);

      if (categoriaSeleccionada === 'todos') {
        mostrarProductos(todosLosProductos);
        return;
      }

      const productosFiltrados = todosLosProductos.filter(producto => {
        // Debug opcional
        console.log("🔎 Producto:", producto.nombre, "Categoria:", producto.categoria);

        return (
          producto.categoria &&
          normalizarTexto(producto.categoria.nombre) === normalizarTexto(categoriaSeleccionada)
        );
      });

      console.log("✅ Filtrados:", productosFiltrados);

      mostrarProductos(productosFiltrados);
    });
  });
}

// 🚀 Inicializar app
obtenerProductos();