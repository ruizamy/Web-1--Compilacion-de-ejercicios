// Variables globales para mantener el estado del cálculo actual
let totalAjustadoGlobal = 0;

function calcularPago() {
    // 1. Captura de datos
    const tipo = document.getElementById('tipo').value;
    const placa = document.getElementById('placa').value.trim();
    const ingreso = new Date(document.getElementById('ingreso').value);
    const salida = new Date(document.getElementById('salida').value);

    // 2. Validación de datos
    if (!placa || isNaN(ingreso) || isNaN(salida)) {
        alert("Por favor, complete todos los campos correctamente.");
        return;
    }

    if (salida <= ingreso) {
        alert("La fecha de salida debe ser posterior a la de ingreso.");
        return;
    }

    // 3. Cálculo de tiempo en minutos
    const diferenciaMs = salida - ingreso;
    const minutosPermanencia = Math.ceil(diferenciaMs / (1000 * 60));

    // 4. Cálculo de Tarifa Base
    const tarifaPorMinuto = (tipo === 'automovil') ? 110 : 80;
    let subtotal = minutosPermanencia * tarifaPorMinuto;

    // 5. Descuento Pico y Placa (Solo Automóviles)
    let descuento = 0;
    if (tipo === 'automovil') {
        // Obtener el último dígito de la placa
        const ultimoDigito = parseInt(placa.slice(-1));
        
        // El enunciado dice: "dependiendo de la fecha... si tienen restricción".
        // Para este ejercicio, simularemos que si el último dígito es par, tiene restricción hoy.
        if (!isNaN(ultimoDigito) && ultimoDigito % 2 === 0) {
            descuento = subtotal * 0.25;
        }
    }

    let totalConDescuento = subtotal - descuento;

    // 6. Ajuste a múltiplos de 50 a favor del parqueadero (Redondeo hacia arriba)
    // Fórmula: Math.ceil(valor / 50) * 50
    totalAjustadoGlobal = Math.ceil(totalConDescuento / 50) * 50;

    // 7. Mostrar resultados en la tabla
    document.getElementById('res-minutos').innerText = minutosPermanencia;
    document.getElementById('res-base').innerText = `$${subtotal.toLocaleString()}`;
    document.getElementById('res-desc').innerText = `-$${descuento.toLocaleString()}`;
    document.getElementById('res-total').innerText = `$${totalAjustadoGlobal.toLocaleString()}`;
}

function procesarPago() {
    const dineroRecibido = parseInt(document.getElementById('pago-cliente').value);
    const contenedorCambio = document.getElementById('cambio-resultado');

    if (isNaN(dineroRecibido) || dineroRecibido < totalAjustadoGlobal) {
        alert("El dinero recibido es insuficiente o inválido.");
        return;
    }

    let cambio = dineroRecibido - totalAjustadoGlobal;

    if (cambio === 0) {
        contenedorCambio.innerHTML = "<strong>Pago exacto. No hay cambio.</strong>";
        return;
    }

    // 8. Lógica de desglose de billetes y monedas
    const denominaciones = [
        { valor: 50000, nombre: "billete(s) de $50.000" },
        { valor: 20000, nombre: "billete(s) de $20.000" },
        { valor: 10000, nombre: "billete(s) de $10.000" },
        { valor: 5000, nombre: "billete(s) de $5.000" },
        { valor: 2000, nombre: "billete(s) de $2.000" },
        { valor: 1000, nombre: "billete(s) de $1.000" },
        { valor: 500, nombre: "moneda(s) de $500" },
        { valor: 200, nombre: "moneda(s) de $200" },
        { valor: 100, nombre: "moneda(s) de $100" },
        { valor: 50, nombre: "moneda(s) de $50" }
    ];

    let resultadoDesglose = `<strong>Cambio Total: $${cambio.toLocaleString()}</strong><br><br>`;
    let tempCambio = cambio;

    denominaciones.forEach(deno => {
        if (tempCambio >= deno.valor) {
            let cantidad = Math.floor(tempCambio / deno.valor);
            tempCambio %= deno.valor;
            resultadoDesglose += `${cantidad} ${deno.nombre}<br>`;
        }
    });

    contenedorCambio.innerHTML = resultadoDesglose;
}