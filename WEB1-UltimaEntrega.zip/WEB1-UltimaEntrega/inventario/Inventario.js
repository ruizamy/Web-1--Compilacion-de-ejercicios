// 1. Selectores del DOM
const btnAgregar = document.getElementById("btnAgregar");
const tablaBody = document.querySelector("#tabla tbody");
const totalGeneral = document.getElementById("totalGeneral");

// 2. Evento Inicial: Cargar los productos guardados cuando la página se termine de abrir
document.addEventListener("DOMContentLoaded", cargarInventario);

// 3. Evento para añadir un nuevo producto desde el formulario
btnAgregar.addEventListener("click", () => {
  const nombre = document.getElementById("nombre").value.trim();
  const cantidad = parseInt(document.getElementById("cantidad").value);
  const precio = parseFloat(document.getElementById("precio").value);

  if (!nombre || isNaN(cantidad) || isNaN(precio)) {
    alert("Por favor complete todos los campos.");
    return;
  }

  agregarProducto(nombre, cantidad, precio);
  limpiar();
  guardarInventario(); // Guarda en el archivo JSON de localStorage cada vez que agregas
});

// 4. Función para renderizar la fila de un producto en la tabla HTML
function agregarProducto(nombre, cantidad, precio) {
  const tr = document.createElement("tr");

  // Si el producto se carga o agrega con cantidad 0, le añade la clase visual de alerta
  if (cantidad === 0) {
    tr.classList.add("low-stock");
  }

  tr.innerHTML = `
      <td>${nombre}</td>
      <td>
          <button class="menos">–</button>
          <span class="cant">${cantidad}</span>
          <button class="mas">+</button>
      </td>
      <td>
          $<span class="precio">${precio.toFixed(2)}</span>
          <button class="editarPrecio">✏️</button>
      </td>
      <td>$<span class="total">${(cantidad * precio).toFixed(2)}</span></td>
      <td><button class="eliminar">🗑️</button></td>
  `;

  tablaBody.appendChild(tr);
  recalcularTotal();
}

// 5. Mantiene limpios los campos del formulario
function limpiar() {
  document.getElementById("nombre").value = "";
  document.getElementById("cantidad").value = "";
  document.getElementById("precio").value = "";
}

// 6. Delegación de eventos para los botones de la tabla (Acciones)
tablaBody.addEventListener("click", function (e) {
  const fila = e.target.closest("tr");
  if (!fila) return;

  // Botón Incrementar (+)
  if (e.target.classList.contains("mas")) {
    let cant = fila.querySelector(".cant");
    cant.textContent = parseInt(cant.textContent) + 1;
    actualizarFila(fila);
  }

  // Botón Decrementar (–)
  if (e.target.classList.contains("menos")) {
    let cant = fila.querySelector(".cant");
    let actual = parseInt(cant.textContent);
    if (actual > 0) {
      cant.textContent = actual - 1;
      actualizarFila(fila);
    }
  }

  // Botón Editar Precio (✏️)
  if (e.target.classList.contains("editarPrecio")) {
    let precioSpan = fila.querySelector(".precio");
    const nuevo = prompt("Nuevo precio:", precioSpan.textContent);
    if (nuevo !== null && !isNaN(parseFloat(nuevo)) && parseFloat(nuevo) >= 0) {
      precioSpan.textContent = parseFloat(nuevo).toFixed(2);
      actualizarFila(fila);
    }
  }

  // Botón Eliminar (🗑️)
  if (e.target.classList.contains("eliminar")) {
    if (confirm("¿Estás seguro de eliminar este producto?")) {
      fila.remove();
    }
  }

  recalcularTotal();
  guardarInventario(); // Guarda los cambios de cualquier acción de forma inmediata
});

// 7. Actualiza los totales internos de la fila y maneja el estado de bajo stock
function actualizarFila(fila) {
  const cant = parseInt(fila.querySelector(".cant").textContent);
  const precio = parseFloat(fila.querySelector(".precio").textContent);

  const total = fila.querySelector(".total");
  total.textContent = (cant * precio).toFixed(2);

  // Control estricto de la alerta visual responsiva
  if (cant === 0) {
    fila.classList.add("low-stock");
  } else {
    fila.classList.remove("low-stock");
  }
}

// 8. Recalcula la suma de todos los subtotales de la tabla
function recalcularTotal() {
  let suma = 0;
  const totales = document.querySelectorAll("#tabla tbody .total");

  totales.forEach((t) => {
    const valor = parseFloat(t.textContent);
    if (!isNaN(valor)) {
      suma += valor;
    }
  });

  totalGeneral.textContent = "Total general: $" + suma.toFixed(2);
}

// 9. FUNCIÓN: Transforma las filas de la tabla a objetos, genera el JSON y lo guarda
function guardarInventario() {
  const filas = document.querySelectorAll("#tabla tbody tr");
  const listaProductos = [];

  filas.forEach((fila) => {
    const nombre = fila.querySelector("td:nth-child(1)").textContent;
    const cantidad = parseInt(fila.querySelector(".cant").textContent);
    const precio = parseFloat(fila.querySelector(".precio").textContent);

    // Creamos una estructura de objeto estructurada para cada producto
    listaProductos.push({
      nombre: nombre,
      cantidad: cantidad,
      precio: precio
    });
  });

  // Convertimos el array de objetos a un documento de texto string estructurado en formato JSON
  const jsonInventario = JSON.stringify(listaProductos);
  
  // Guardamos de manera indefinida en el espacio local del navegador
  localStorage.setItem("archivo_inventario", jsonInventario);
}

// 10. FUNCIÓN: Lee el JSON desde la memoria, lo decodifica y reconstruye la interfaz al iniciar
function cargarInventario() {
  const datosGuardados = localStorage.getItem("archivo_inventario");

  // Si el archivo JSON no existe (primera vez que abres la app), salimos sin romper nada
  if (!datosGuardados) return;

  try {
    // Convertimos el string JSON de vuelta a un arreglo de objetos nativos de JavaScript
    const productos = JSON.parse(datosGuardados);

    // Iteramos e inyectamos secuencialmente cada elemento guardado en la tabla
    productos.forEach((producto) => {
      agregarProducto(producto.nombre, producto.cantidad, producto.precio);
    });
  } catch (error) {
    console.error("Error al procesar el archivo JSON de inventario:", error);
  }
}