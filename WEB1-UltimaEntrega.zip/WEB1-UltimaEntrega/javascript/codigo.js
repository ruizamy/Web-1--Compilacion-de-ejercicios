// //Uso de variables
// var nombre = 'CESDE';
// console.log(nombre);
// console.log(typeof(nombre));

// var edad = 52;
// console.log(edad);
// console.log(typeof(edad));

// edad = 'Cinco';
// console.log(edad);
// console.log(typeof(edad));

// var sueldo = 1300000.99;
// console.log(sueldo);
// console.log(typeof(sueldo));

// var tieneTrabajo = false;
// console.log(tieneTrabajo);
// console.log(typeof(tieneTrabajo));

// var salon;
// console.log(salon);

// puestoDeTrabajo = null;
// console.log(puestoDeTrabajo);


// //intanciacion de objetos 
// let persona = {nombre: 'JORGE', edad: 56, tel:3124567893};
// document.writeln(persona.nombre);
// document.writeln('<br>');
// document.writeln(persona.edad);
// document.writeln('<br>');
// document.writeln(persona.tel);

// //  * Operadores matemáticos +, -, *, /
 

//  var edadAna, edadMaria, diferenciaEdad;
//  var sumaEdades, yearAna, yearMaria, yearActual;

//  edadAna = 34;
//  edadMaria = 28;
//  yearActual = 2026;

// diferenciaEdad = edadAna - edadMaria;
// sumaEdades = edadAna + edadMaria;

// yearAna = yearActual - edadAna;
// yearMaria = yearActual - edadMaria;

// console.log(diferenciaEdad);
// console.log(sumaEdades);
// console.log('Año en que nació Ana ' + yearAna);
// console.log('Año en que nació María ' + yearMaria);
// console.log(yearActual * 5);
// console.log(yearActual / 2)
// document.writeln('<br>');

// let nombres, edades, correo;
// nombres = prompt("Ingrese su nombre ...");
// edades = prompt('Ingrese su edad');
// correo = prompt("Escriba su usuario de correo");
// document.writeln('<br>');
// document.writeln('NOMBRE: '+ nombres); document.writeln('<br>');
// document.writeln('EDAD: ', edades, 'años');
// document.writeln('<br>');
// document.writeln('E-MAIL: '+ correo);



let numero3S, unidades, decenas, centenas, residuo;
numero3S = prompt("Ingrese un numero de tres cifras");
centenas = Math.trunc(numero3S / 100);
residuo = numero3S % 100;
decenas = Math.trunc(residuo / 10);
unidades = residuo % 10;

document.writeln('Centenas:',centenas);

document.writeln('Decenas:',decenas);

document.writeln('Unidades:',unidades);
 